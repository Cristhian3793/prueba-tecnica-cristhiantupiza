-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-02-2021 a las 01:53:27
-- Versión del servidor: 10.4.10-MariaDB
-- Versión de PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbfisiodaec`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cabcompra`
--

CREATE TABLE `cabcompra` (
  `idCompra` bigint(20) NOT NULL,
  `codCompra` bigint(11) DEFAULT NULL,
  `nomProveedor` varchar(100) DEFAULT NULL,
  `usuCreacion` varchar(20) DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `totalCompra` decimal(11,2) DEFAULT NULL,
  `ivaCompra` double NOT NULL,
  `totalconIva` double NOT NULL,
  `usuModificacion` varchar(150) DEFAULT NULL,
  `fechaModificacion` date DEFAULT NULL,
  `tipoDocumento` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cabcompra`
--

INSERT INTO `cabcompra` (`idCompra`, `codCompra`, `nomProveedor`, `usuCreacion`, `fechaCreacion`, `totalCompra`, `ivaCompra`, `totalconIva`, `usuModificacion`, `fechaModificacion`, `tipoDocumento`) VALUES
(1, 1, 'Proveedor juguetes', 'ctupiza', '2020-12-02', '942.00', 113.04000091552734, 1055.0400390625, NULL, NULL, 'COMP'),
(2, 2, 'Proveedor juguetes', 'ctupiza', '2020-12-01', '198.00', 23.760000228881836, 221.75999450683594, NULL, NULL, 'COMP'),
(3, 3, 'Proveedor juguetes', 'ctupiza', '2020-12-02', '138.00', 16.559999465942383, 154.55999755859375, NULL, NULL, 'COMP'),
(4, 4, 'Proveedor vasos', 'ctupiza', '2020-12-03', '276.00', 33.119998931884766, 309.1199951171875, NULL, NULL, 'COMP'),
(7, 5, 'Proveedor Vasos', 'ctupiza', '2020-12-08', '435.00', 52.20000076293945, 487.20001220703125, NULL, NULL, 'COMP'),
(8, 10, 'Proveedor Comics', 'ctupiza', '2020-12-02', '942.00', 113.04000091552734, 1055.0400390625, NULL, NULL, 'COMP');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cabventa`
--

CREATE TABLE `cabventa` (
  `idVenta` bigint(20) NOT NULL,
  `codVenta` bigint(11) DEFAULT NULL,
  `nomcliente` varchar(100) DEFAULT NULL,
  `identificacion` varchar(10) NOT NULL,
  `totalVenta` decimal(10,2) DEFAULT NULL,
  `ivaVenta` float NOT NULL,
  `totalconIva` float NOT NULL,
  `usuCreacion` varchar(30) DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `usuModificacion` varchar(30) DEFAULT NULL,
  `fechaModificacion` date DEFAULT NULL,
  `tipoDocumento` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cabventa`
--

INSERT INTO `cabventa` (`idVenta`, `codVenta`, `nomcliente`, `identificacion`, `totalVenta`, `ivaVenta`, `totalconIva`, `usuCreacion`, `fechaCreacion`, `usuModificacion`, `fechaModificacion`, `tipoDocumento`) VALUES
(2, 1, 'Cristhian Alexis Tupiza Haro', '1721441895', '125.00', 15, 140, 'ctupiza', '2020-12-02', NULL, NULL, 'VENT'),
(3, 2, 'Maria Fernanda Tupiza Haro', '1718418625', '261.00', 31.32, 292.32, 'ctupiza', '2020-12-02', NULL, NULL, 'VENT'),
(4, 3, 'Jorge Luis Tupiza', '123456789', '234.00', 28.08, 262.08, 'ctupiza', '2020-12-03', NULL, NULL, 'VENT');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `cliID` int(11) NOT NULL,
  `cliNombres` varchar(150) NOT NULL,
  `cliApellidos` varchar(150) NOT NULL,
  `cliEmail` varchar(50) NOT NULL,
  `cliTelefono` varchar(10) NOT NULL,
  `cliDireccion` varchar(50) NOT NULL,
  `identificacion` bigint(20) NOT NULL,
  `fechaRegistro` date NOT NULL,
  `usuCreacion` varchar(50) NOT NULL,
  `fechaModificacion` date DEFAULT NULL,
  `usuModificacion` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`cliID`, `cliNombres`, `cliApellidos`, `cliEmail`, `cliTelefono`, `cliDireccion`, `identificacion`, `fechaRegistro`, `usuCreacion`, `fechaModificacion`, `usuModificacion`) VALUES
(1, 'Maria Fernanda', 'Tupiza Haro', 'marifer2612@yahoo.es', '0982902770', 'San Carlos y Vaca de Castro N89-001', 1718418625, '2020-12-02', 'ctupiza', NULL, NULL),
(2, 'Nestor Fabian', 'Lopez Duque', 'lopez.fabian_0281@yahoo.com', '0999923990', 'Av Cotopaxi y Ruben Dario OE12-26', 1803761285, '2020-12-02', 'ctupiza', NULL, NULL),
(3, 'Cristhian Alexis', 'Tupiza Haro', 'cris.alexis.th@gmail.com', '0981011686', 'Las Casas OE10-126 y Mariscal Sucre', 1721441895, '2020-12-02', 'ctupiza', NULL, NULL),
(4, 'Jorge Luis', 'Tupiza', 'cris.alexis.th@gmail.com', '0232007891', 'Bartolomé de las Casas', 123456789, '2020-12-03', 'ctupiza', NULL, NULL),
(5, 'Jorge Luis', 'Tupiza', 'cris.alexis.th@gmail.com', '0232007891', 'Bartolomé de las Casas', 123456789, '2020-12-03', 'ctupiza', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `codCompra` bigint(20) NOT NULL,
  `fechaCreacion` date NOT NULL,
  `fechaModificacion` date NOT NULL,
  `idCompra` bigint(20) NOT NULL,
  `ivaCompra` decimal(10,0) NOT NULL,
  `nomProveedor` varchar(30) NOT NULL,
  `tipoDocumento` varchar(30) NOT NULL,
  `totalCompra` decimal(10,0) NOT NULL,
  `totalconIva` decimal(10,0) NOT NULL,
  `usuCreacion` varchar(30) NOT NULL,
  `usuModificacion` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`codCompra`, `fechaCreacion`, `fechaModificacion`, `idCompra`, `ivaCompra`, `nomProveedor`, `tipoDocumento`, `totalCompra`, `totalconIva`, `usuCreacion`, `usuModificacion`) VALUES
(1, '0000-00-00', '0000-00-00', 0, '20201202', '942.00', '113.04000091552734', '1055', '0', '', 'COMP'),
(2, '0000-00-00', '0000-00-00', 0, '20201201', '198.00', '23.760000228881836', '222', '0', '', 'COMP'),
(3, '0000-00-00', '0000-00-00', 0, '20201202', '138.00', '16.559999465942383', '155', '0', '', 'COMP'),
(4, '0000-00-00', '0000-00-00', 0, '20201203', '276.00', '33.119998931884766', '309', '0', '', 'COMP'),
(7, '0000-00-00', '0000-00-00', 0, '20201208', '435.00', '52.20000076293945', '487', '0', '', 'COMP');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detcompra`
--

CREATE TABLE `detcompra` (
  `idDetCompra` int(11) NOT NULL,
  `codCompra` bigint(11) DEFAULT NULL,
  `idProducto` int(11) DEFAULT NULL,
  `nomProducto` varchar(100) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `preUnitario` decimal(10,2) DEFAULT NULL,
  `preTotal` decimal(11,2) DEFAULT NULL,
  `usuCreacion` varchar(20) DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `tipoDocumento` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `detcompra`
--

INSERT INTO `detcompra` (`idDetCompra`, `codCompra`, `idProducto`, `nomProducto`, `cantidad`, `preUnitario`, `preTotal`, `usuCreacion`, `fechaCreacion`, `tipoDocumento`) VALUES
(1, 1, 1, 'comic spiderman', 5, '46.00', '230.00', 'ctupiza', '2020-12-02', 'COMP'),
(2, 1, 2, 'vaso hulk', 4, '33.00', '132.00', 'ctupiza', '2020-12-02', 'COMP'),
(3, 1, 3, 'juguete peluche', 5, '116.00', '580.00', 'ctupiza', '2020-12-02', 'COMP'),
(4, 2, 2, 'vaso hulk', 6, '33.00', '198.00', 'ctupiza', '2020-12-01', 'COMP'),
(5, 3, 1, 'comic spiderman', 3, '46.00', '138.00', 'ctupiza', '2020-12-02', 'COMP'),
(6, 4, 3, 'juguete peluche', 1, '116.00', '116.00', 'ctupiza', '2020-12-03', 'COMP'),
(7, 4, 4, 'camiseta DC', 2, '80.00', '160.00', 'ctupiza', '2020-12-03', 'COMP'),
(12, 5, 1, 'comic spiderman', 1, '46.00', '46.00', 'ctupiza', '2020-12-08', 'COMP'),
(13, 5, 2, 'vaso hulk', 1, '33.00', '33.00', 'ctupiza', '2020-12-08', 'COMP'),
(14, 5, 3, 'juguete peluche', 1, '116.00', '116.00', 'ctupiza', '2020-12-08', 'COMP'),
(15, 5, 4, 'camiseta DC', 1, '80.00', '80.00', 'ctupiza', '2020-12-08', 'COMP'),
(16, 5, 4, 'camiseta DC', 2, '80.00', '160.00', 'ctupiza', '2020-12-08', 'COMP');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detventa`
--

CREATE TABLE `detventa` (
  `idDetVenta` bigint(20) NOT NULL,
  `codVenta` bigint(11) DEFAULT NULL,
  `idProducto` int(11) DEFAULT NULL,
  `nomProducto` varchar(100) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `preUnitario` decimal(10,2) DEFAULT NULL,
  `preTotal` decimal(10,2) DEFAULT NULL,
  `usuCreacion` varchar(20) DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `tipoDocumento` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `detventa`
--

INSERT INTO `detventa` (`idDetVenta`, `codVenta`, `idProducto`, `nomProducto`, `cantidad`, `preUnitario`, `preTotal`, `usuCreacion`, `fechaCreacion`, `tipoDocumento`) VALUES
(3, 1, 1, 'comic spiderman', 1, '49.00', '49.00', 'ctupiza', '2020-12-02', 'VENT'),
(4, 1, 2, 'vaso hulk', 2, '38.00', '76.00', 'ctupiza', '2020-12-02', 'VENT'),
(5, 2, 1, 'comic spiderman', 1, '49.00', '49.00', 'ctupiza', '2020-12-02', 'VENT'),
(6, 2, 3, 'juguete peluche', 1, '136.00', '136.00', 'ctupiza', '2020-12-02', 'VENT'),
(7, 2, 2, 'vaso hulk', 2, '38.00', '76.00', 'ctupiza', '2020-12-02', 'VENT'),
(8, 3, 1, 'comic spiderman', 2, '49.00', '98.00', 'ctupiza', '2020-12-03', 'VENT'),
(9, 3, 3, 'juguete peluche', 1, '136.00', '136.00', 'ctupiza', '2020-12-03', 'VENT'),
(10, 3, 2, 'vaso hulk', 3, '2.00', '3.00', 'ctupiza', '0000-00-00', 'vent');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `emails`
--

CREATE TABLE `emails` (
  `idEmail` int(11) NOT NULL,
  `idProveedor` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `emails`
--

INSERT INTO `emails` (`idEmail`, `idProveedor`, `email`) VALUES
(1, 1, 'intermedical@hotmail.com'),
(2, 2, 'galo_vargas378@yahoo.com'),
(3, 3, 'rehabilitar@hotmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kardex`
--

CREATE TABLE `kardex` (
  `idKardex` int(11) NOT NULL,
  `idProducto` int(11) DEFAULT NULL,
  `fecha` date DEFAULT current_timestamp(),
  `tipoDocumento` varchar(30) DEFAULT NULL,
  `entrada` decimal(11,2) DEFAULT NULL,
  `salida` decimal(11,2) DEFAULT NULL,
  `saldo` decimal(11,2) DEFAULT NULL,
  `tipoMovimiento` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `kardex`
--

INSERT INTO `kardex` (`idKardex`, `idProducto`, `fecha`, `tipoDocumento`, `entrada`, `salida`, `saldo`, `tipoMovimiento`) VALUES
(63, 1, '2020-12-02', 'COMP', '5.00', NULL, NULL, NULL),
(64, 2, '2020-12-02', 'COMP', '4.00', NULL, NULL, NULL),
(65, 3, '2020-12-02', 'COMP', '5.00', NULL, NULL, NULL),
(66, 2, '2020-12-01', 'COMP', '6.00', NULL, NULL, NULL),
(67, 1, '2020-12-02', 'VENT', NULL, '1.00', NULL, NULL),
(68, 2, '2020-12-02', 'VENT', NULL, '2.00', NULL, NULL),
(69, 1, '2020-12-02', 'VENT', NULL, '1.00', NULL, NULL),
(70, 2, '2020-12-02', 'VENT', NULL, '2.00', NULL, NULL),
(71, 1, '2020-12-02', 'VENT', NULL, '1.00', NULL, NULL),
(72, 3, '2020-12-02', 'VENT', NULL, '1.00', NULL, NULL),
(73, 2, '2020-12-02', 'VENT', NULL, '2.00', NULL, NULL),
(74, 1, '2020-12-02', 'COMP', '3.00', NULL, NULL, NULL),
(75, 3, '2020-12-03', 'COMP', '1.00', NULL, NULL, NULL),
(76, 4, '2020-12-03', 'COMP', '2.00', NULL, NULL, NULL),
(77, 1, '2020-12-03', 'VENT', NULL, '2.00', NULL, NULL),
(78, 3, '2020-12-03', 'VENT', NULL, '1.00', NULL, NULL),
(79, 1, '2020-12-08', 'COMP', '2.00', NULL, NULL, NULL),
(80, 2, '2020-12-08', 'COMP', '1.00', NULL, NULL, NULL),
(81, 3, '2020-12-08', 'COMP', '1.00', NULL, NULL, NULL),
(82, 4, '2020-12-08', 'COMP', '1.00', NULL, NULL, NULL),
(83, 1, '2020-12-08', 'COMP', '1.00', NULL, NULL, NULL),
(84, 2, '2020-12-08', 'COMP', '1.00', NULL, NULL, NULL),
(85, 3, '2020-12-08', 'COMP', '1.00', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `idProd` int(11) NOT NULL,
  `nomProd` varchar(150) DEFAULT NULL,
  `desProd` decimal(10,2) DEFAULT NULL,
  `barProd` bigint(20) DEFAULT NULL,
  `codProd` varchar(20) DEFAULT NULL,
  `preFact` decimal(10,2) DEFAULT NULL,
  `preExtr` decimal(10,2) DEFAULT NULL,
  `cosProd` decimal(10,2) DEFAULT NULL,
  `ganProd` decimal(10,2) DEFAULT NULL,
  `preVent` decimal(10,2) DEFAULT NULL,
  `preDesc` decimal(10,2) DEFAULT NULL,
  `preTotal` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`idProd`, `nomProd`, `desProd`, `barProd`, `codProd`, `preFact`, `preExtr`, `cosProd`, `ganProd`, `preVent`, `preDesc`, `preTotal`) VALUES
(1, 'comic spiderman', '0.00', 7861001301168, 'COL001', '46.00', '0.00', '46.00', '3.00', '49.00', '49.00', '49.00'),
(2, 'vaso hulk', '0.00', 3607347411536, 'COMP001', '33.00', '0.00', '33.00', '5.00', '38.00', '38.00', '38.00'),
(3, 'juguete peluche', '0.00', 7862113073240, 'BOSU001', '116.00', '0.00', '116.00', '20.00', '136.00', '136.00', '136.00'),
(4, 'camiseta DC', '0.00', 12233434322, 'CAM001', '80.00', '0.00', '80.00', '90.00', '170.00', '170.00', '170.00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `idProveedor` int(11) NOT NULL,
  `nomProveedor` varchar(100) DEFAULT NULL,
  `dirProveedor` varchar(100) DEFAULT NULL,
  `obsProveedor` varchar(250) DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `usuCreacion` varchar(100) DEFAULT NULL,
  `usuMod` varchar(20) DEFAULT NULL,
  `fechaMod` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`idProveedor`, `nomProveedor`, `dirProveedor`, `obsProveedor`, `fechaCreacion`, `usuCreacion`, `usuMod`, `fechaMod`) VALUES
(1, 'Proveedor juguetes', 'Av Roca E8-18 y Av. 6 de Diciembre', NULL, '2020-12-02', 'ctupiza', NULL, NULL),
(2, 'Proveedor Vasos', 'America y Santiago N17-213', NULL, '2020-12-02', 'ctupiza', NULL, NULL),
(3, 'Proveedor Comics', 'Mariana de jesus', NULL, '2020-12-03', 'ctupiza', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefonos`
--

CREATE TABLE `telefonos` (
  `idTelefono` int(11) NOT NULL,
  `idProveedor` int(11) NOT NULL,
  `telfTipo` varchar(100) DEFAULT NULL,
  `telfNum` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `telefonos`
--

INSERT INTO `telefonos` (`idTelefono`, `idProveedor`, `telfTipo`, `telfNum`) VALUES
(1, 1, 'Oficina', '256-2341'),
(2, 1, 'Oficina', '256-2342'),
(3, 1, 'Oficina', '222-2981'),
(4, 2, 'Oficina', '2502631'),
(5, 2, 'Celular', '0992744916'),
(6, 3, 'Casa', '023200789'),
(7, 3, 'Oficina', '0979979980');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temproductos`
--

CREATE TABLE `temproductos` (
  `id` int(11) NOT NULL,
  `codProducto` decimal(11,2) DEFAULT NULL,
  `nomProducto` text DEFAULT NULL,
  `cantProducto` decimal(10,0) DEFAULT NULL,
  `costProducto` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `temproductos`
--

INSERT INTO `temproductos` (`id`, `codProducto`, `nomProducto`, `cantProducto`, `costProducto`) VALUES
(80, NULL, NULL, NULL, NULL),
(81, '15.00', NULL, NULL, NULL),
(82, '14.00', NULL, NULL, NULL),
(83, '11.00', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipousuario`
--

CREATE TABLE `tipousuario` (
  `idTipoUsuario` int(11) NOT NULL,
  `perfil` varchar(100) NOT NULL,
  `habilitado` tinyint(1) NOT NULL,
  `fechaCreacion` date NOT NULL,
  `usuCreacion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipousuario`
--

INSERT INTO `tipousuario` (`idTipoUsuario`, `perfil`, `habilitado`, `fechaCreacion`, `usuCreacion`) VALUES
(1, 'Administrador', 1, '2020-07-15', 'cris'),
(2, 'Ventas', 1, '2020-07-15', 'cris'),
(3, 'Compras', 1, '2020-07-15', 'cris');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `USUID` int(11) NOT NULL,
  `USUALIAS` varchar(100) NOT NULL,
  `USUCLAVE` text NOT NULL,
  `USUNOMBRE` varchar(100) NOT NULL,
  `USUAPELLIDO` varchar(100) NOT NULL,
  `USUTIPO` int(11) NOT NULL,
  `USUFECHACREACION` date DEFAULT NULL,
  `USUESTADO` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`USUID`, `USUALIAS`, `USUCLAVE`, `USUNOMBRE`, `USUAPELLIDO`, `USUTIPO`, `USUFECHACREACION`, `USUESTADO`) VALUES
(1, 'ctupiza', 'eyJpdiI6Ik93bnZOWlNiMDE1Ylo3cTRlRm14Z0E9PSIsInZhbHVlIjoidGxSREJaMmw0YjZEUzl6Z0s5WEErdz09IiwibWFjIjoiYzk2Yjk1OGE4YjFlM2FkMzk5NTM4N2QyYjI4ZWIwYzE2ZTkzZGYwNDJhY2FmYmZmZDAyMTc3MTE3NzIzZjlhNSJ9', 'cristhian', 'tupiza', 1, '2020-01-13', 1),
(2, 'jpruna', 'eyJpdiI6IldLUEdGNEFIclVwNTNBR0N3dHlncnc9PSIsInZhbHVlIjoiSjV2MEo5ZXdyNUE3aldweTcxTHVsdz09IiwibWFjIjoiODZmNjAwOWIyMDUzYzllNzAzMjA3YThiMzU2NzhjMWE3NGIzOTkzNjM2Yjc0OWFkYmU5NzlkN2YwNmE1MGZkYSJ9', 'Jorge', 'Pruna', 3, '2020-01-13', 1),
(3, 'rharo', 'eyJpdiI6IldLUEdGNEFIclVwNTNBR0N3dHlncnc9PSIsInZhbHVlIjoiSjV2MEo5ZXdyNUE3aldweTcxTHVsdz09IiwibWFjIjoiODZmNjAwOWIyMDUzYzllNzAzMjA3YThiMzU2NzhjMWE3NGIzOTkzNjM2Yjc0OWFkYmU5NzlkN2YwNmE1MGZkYSJ9', 'Rosa', 'Haro', 2, '2020-01-13', 1),
(6, 'pduque', 'eyJpdiI6IldLUEdGNEFIclVwNTNBR0N3dHlncnc9PSIsInZhbHVlIjoiSjV2MEo5ZXdyNUE3aldweTcxTHVsdz09IiwibWFjIjoiODZmNjAwOWIyMDUzYzllNzAzMjA3YThiMzU2NzhjMWE3NGIzOTkzNjM2Yjc0OWFkYmU5NzlkN2YwNmE1MGZkYSJ9', 'Patricio', 'Duque', 3, '2020-07-16', 0),
(11, 'fharo', 'eyJpdiI6IldLUEdGNEFIclVwNTNBR0N3dHlncnc9PSIsInZhbHVlIjoiSjV2MEo5ZXdyNUE3aldweTcxTHVsdz09IiwibWFjIjoiODZmNjAwOWIyMDUzYzllNzAzMjA3YThiMzU2NzhjMWE3NGIzOTkzNjM2Yjc0OWFkYmU5NzlkN2YwNmE1MGZkYSJ9', 'fernada', 'haro', 2, '2020-11-24', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cabcompra`
--
ALTER TABLE `cabcompra`
  ADD PRIMARY KEY (`idCompra`),
  ADD UNIQUE KEY `codCompra` (`codCompra`);

--
-- Indices de la tabla `cabventa`
--
ALTER TABLE `cabventa`
  ADD PRIMARY KEY (`idVenta`),
  ADD KEY `codVenta` (`codVenta`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`cliID`);

--
-- Indices de la tabla `detcompra`
--
ALTER TABLE `detcompra`
  ADD PRIMARY KEY (`idDetCompra`),
  ADD KEY `codCompra` (`codCompra`);

--
-- Indices de la tabla `detventa`
--
ALTER TABLE `detventa`
  ADD PRIMARY KEY (`idDetVenta`),
  ADD KEY `detventa_ibfk_1` (`codVenta`);

--
-- Indices de la tabla `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`idEmail`),
  ADD KEY `idProveedor` (`idProveedor`);

--
-- Indices de la tabla `kardex`
--
ALTER TABLE `kardex`
  ADD PRIMARY KEY (`idKardex`),
  ADD KEY `idProducto` (`idProducto`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`idProd`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`idProveedor`);

--
-- Indices de la tabla `telefonos`
--
ALTER TABLE `telefonos`
  ADD PRIMARY KEY (`idTelefono`),
  ADD KEY `idProveedor` (`idProveedor`);

--
-- Indices de la tabla `temproductos`
--
ALTER TABLE `temproductos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipousuario`
--
ALTER TABLE `tipousuario`
  ADD PRIMARY KEY (`idTipoUsuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`USUID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cabcompra`
--
ALTER TABLE `cabcompra`
  MODIFY `idCompra` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `cabventa`
--
ALTER TABLE `cabventa`
  MODIFY `idVenta` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `cliID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `detcompra`
--
ALTER TABLE `detcompra`
  MODIFY `idDetCompra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `detventa`
--
ALTER TABLE `detventa`
  MODIFY `idDetVenta` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `emails`
--
ALTER TABLE `emails`
  MODIFY `idEmail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `kardex`
--
ALTER TABLE `kardex`
  MODIFY `idKardex` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `idProd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `idProveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `telefonos`
--
ALTER TABLE `telefonos`
  MODIFY `idTelefono` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `temproductos`
--
ALTER TABLE `temproductos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT de la tabla `tipousuario`
--
ALTER TABLE `tipousuario`
  MODIFY `idTipoUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `USUID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detcompra`
--
ALTER TABLE `detcompra`
  ADD CONSTRAINT `detcompra_ibfk_1` FOREIGN KEY (`codCompra`) REFERENCES `cabcompra` (`codCompra`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `detventa`
--
ALTER TABLE `detventa`
  ADD CONSTRAINT `detventa_ibfk_1` FOREIGN KEY (`codVenta`) REFERENCES `cabventa` (`codVenta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `emails`
--
ALTER TABLE `emails`
  ADD CONSTRAINT `emails_ibfk_1` FOREIGN KEY (`idProveedor`) REFERENCES `proveedor` (`idProveedor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `kardex`
--
ALTER TABLE `kardex`
  ADD CONSTRAINT `kardex_ibfk_1` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProd`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `telefonos`
--
ALTER TABLE `telefonos`
  ADD CONSTRAINT `telefonos_ibfk_1` FOREIGN KEY (`idProveedor`) REFERENCES `proveedor` (`idProveedor`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
