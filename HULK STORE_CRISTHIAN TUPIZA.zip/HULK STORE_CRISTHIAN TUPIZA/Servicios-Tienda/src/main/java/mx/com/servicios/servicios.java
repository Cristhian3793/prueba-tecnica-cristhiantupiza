/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.servicios;
import java.util.Date;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.CabCompra;
import modelo.CabCompraDAO;
import modelo.CabVenta;
import modelo.CabVentaDAO;
import modelo.DetCompra;
import modelo.DetCompraDAO;
import modelo.DetVenta;
import modelo.DetVentaDAO;
import modelo.Kardex;
import modelo.KardexDAO;
import modelo.ProductoDAO;
import modelo.Producto;
import modelo.Usuario;
import modelo.UsuarioDAO;

/**
 *
 * @author CRISTHIAN TUPIZA
 */
@WebService(serviceName = "servicios")
public class servicios {
CabCompraDAO dao=new CabCompraDAO();
CabVentaDAO daov=new CabVentaDAO();
ProductoDAO daop=new ProductoDAO();
KardexDAO kar=new KardexDAO();
DetCompraDAO detcom=new DetCompraDAO();
DetVentaDAO detven=new DetVentaDAO();
UsuarioDAO usu=new UsuarioDAO();
    /**
     * 
     * @return 
     */
    @WebMethod(operationName = "listarcompra")
    public List<CabCompra> listarcompra() {
        List datos=dao.listarcompra(); 
        return datos;
    }

    /**
     * 
     */
    @WebMethod(operationName = "agregarcompra")
    public String agregarcompra( @WebParam(name = "nomProveedor") String nomProveedor, @WebParam(name = "usuCreacion") String usuCreacion, @WebParam(name = "fechaCreacion") Date fechaCreacion, @WebParam(name = "totalCompra") double totalCompra, @WebParam(name = "ivaCompra") double ivaCompra, @WebParam(name = "totalconIva") double totalconIva, @WebParam(name = "usuModificacion") String usuModificacion, @WebParam(name = "fechaModificacion") Date fechaModificacion, @WebParam(name = "tipoDocumento") String tipoDocumento) {
        //TODO write your implementation code here:
        String datos=dao.agregarcompra(nomProveedor, usuCreacion, fechaCreacion, totalCompra, ivaCompra, totalconIva, usuModificacion, fechaModificacion, tipoDocumento);      
        return datos;
    }



    @WebMethod(operationName = "agregarventa")
    public String agregarventa(@WebParam(name = "nomcliente") String nomcliente, @WebParam(name = "identificacion") String identificacion, @WebParam(name = "totalventa") double totalventa, @WebParam(name = "ivaVenta") double ivaVenta, @WebParam(name = "totalconIva") double totalconIva, @WebParam(name = "usucreacion") String usucreacion, @WebParam(name = "fechaCreacion") Date fechaCreacion, @WebParam(name = "usuModificacion") String usuModificacion, @WebParam(name = "fechaModificacion") Date fechaModificacion, @WebParam(name = "tipoDocumento") String tipoDocumento) {
        String datos=daov.agregarventa(nomcliente, identificacion, totalventa, ivaVenta, totalconIva,usucreacion,fechaCreacion,usuModificacion, fechaModificacion, tipoDocumento);
        return datos;
    }

    @WebMethod(operationName = "listarventa")
    public List<CabVenta> listarventa() {
        List datos=daov.listarventas(); 
        return datos;
    }


    @WebMethod(operationName = "listarproductos")
    public List<Producto> listarproductos() {
        List datos=daop.listarproductos();
        return datos;
    }

    @WebMethod(operationName = "listarkardex")
    public List<Kardex> listarkardex() {
        List datos=kar.listarkardex();
        return datos;
    }

    @WebMethod(operationName = "agregarkardex")
    public String agregarKardex(@WebParam(name = "idProducto") int idProducto,@WebParam(name = "fecha") Date fecha, @WebParam(name = "tipoDocumento") String tipoDocumento, @WebParam(name = "entrada") double entrada, @WebParam(name = "salida") double salida, @WebParam(name = "saldo") double saldo, @WebParam(name = "tipoMovimiento") String tipoMovimiento) {
        String datos=kar.agregarKardex(idProducto,fecha, tipoDocumento, entrada, salida, saldo,tipoMovimiento);
        return datos;
    }

    @WebMethod(operationName = "listarDetCompra")
    public List<DetCompra> listarDetCompra() {
        List datos=detcom.listarDetCompra();
        return datos;
    }

    @WebMethod(operationName = "insertarDetCompra")
    public String insertarDetCompra(@WebParam(name = "codCompra") long codCompra, @WebParam(name = "idProducto") int idProducto, @WebParam(name = "nomProducto") String nomProducto, @WebParam(name = "cantidad") int cantidad, @WebParam(name = "preUnitario") double preUnitario, @WebParam(name = "preTotal") double preTotal,@WebParam(name = "usuCreacion") String usuCreacion,@WebParam(name = "fechaCreacion") Date fechaCreacion ,@WebParam(name = "tipoDocumento") String tipoDocumento) {
    String datos=detcom.insertarDetCompra(codCompra, idProducto, nomProducto, cantidad, preUnitario,preTotal,usuCreacion,fechaCreacion,tipoDocumento);
    return datos;
    }


    @WebMethod(operationName = "listarDetVenta")
    public List<DetVenta> listarDetVenta() {
        List datos=detven.listarDetVenta();
        return datos;
    }

    @WebMethod(operationName = "insertarDetVenta")
    public String insertarDetVenta(@WebParam(name = "codVenta") long codVenta, @WebParam(name = "idProducto") int idProducto, @WebParam(name = "nomProducto") String nomProducto, @WebParam(name = "cantidad") int cantidad, @WebParam(name = "preUnitario") double preUnitario, @WebParam(name = "preTotal") double preTotal,@WebParam(name = "usuCreacion") String usuCreacion,@WebParam(name = "fechaCreacion") Date fechaCreacion ,@WebParam(name = "tipoDocumento") String tipoDocumento) {
    String datos=detven.insertarDetVenta(codVenta, idProducto, nomProducto, cantidad, preUnitario,preTotal,usuCreacion,fechaCreacion,tipoDocumento);
    return datos;
    }

    @WebMethod(operationName = "listarusuarios")
    public List<Usuario> listarUsuarios() {
        List datos=usu.listarUsuarios();
        return datos;
    }

    @WebMethod(operationName = "insertarUsuario")
    public String agregarUsuario(@WebParam(name = "USUALIAS") String USUALIAS, @WebParam(name = "USUCLAVE") String USUCLAVE, @WebParam(name = "USUNOMBRE") String USUNOMBRE, @WebParam(name = "USUAPELLIDO") String USUAPELLIDO, @WebParam(name = "USUTIPO") int USUTIPO, @WebParam(name = "USUFECHACREACION") Date USUFECHACREACION,@WebParam(name = "USUESTADO") short USUESTADO) {
    String datos=usu.agregarUsuario(USUALIAS, USUCLAVE, USUNOMBRE, USUAPELLIDO, USUTIPO,USUFECHACREACION,USUESTADO);
    return datos;
    }
    
}
