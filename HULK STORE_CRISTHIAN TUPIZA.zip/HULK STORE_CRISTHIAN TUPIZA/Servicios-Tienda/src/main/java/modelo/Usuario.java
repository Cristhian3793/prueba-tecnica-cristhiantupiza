/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;

/**
 *
 * @author USER
 */
public class Usuario {
    private int USUID;
    private String USUALIAS;
    private String USUCLAVE;
    private String USUNOMBRE;
    private String USUAPELLIDO;
    private int USUTIPO;
    private Date USUFECHACREACION;
    private short USUESTADO;

    public Usuario() {
    }

    public Usuario(int USUID, String USUALIAS, String USUCLAVE, String USUNOMBRE, String USUAPELLIDO, int USUTIPO, Date USUFECHACREACION, short USUESTADO) {
        this.USUID = USUID;
        this.USUALIAS = USUALIAS;
        this.USUCLAVE = USUCLAVE;
        this.USUNOMBRE = USUNOMBRE;
        this.USUAPELLIDO = USUAPELLIDO;
        this.USUTIPO = USUTIPO;
        this.USUFECHACREACION = USUFECHACREACION;
        this.USUESTADO = USUESTADO;
    }

    public int getUSUID() {
        return USUID;
    }

    public void setUSUID(int USUID) {
        this.USUID = USUID;
    }

    public String getUSUALIAS() {
        return USUALIAS;
    }

    public void setUSUALIAS(String USUALIAS) {
        this.USUALIAS = USUALIAS;
    }

    public String getUSUCLAVE() {
        return USUCLAVE;
    }

    public void setUSUCLAVE(String USUCLAVE) {
        this.USUCLAVE = USUCLAVE;
    }

    public String getUSUNOMBRE() {
        return USUNOMBRE;
    }

    public void setUSUNOMBRE(String USUNOMBRE) {
        this.USUNOMBRE = USUNOMBRE;
    }

    public String getUSUAPELLIDO() {
        return USUAPELLIDO;
    }

    public void setUSUAPELLIDO(String USUAPELLIDO) {
        this.USUAPELLIDO = USUAPELLIDO;
    }

    public int getUSUTIPO() {
        return USUTIPO;
    }

    public void setUSUTIPO(int USUTIPO) {
        this.USUTIPO = USUTIPO;
    }

    public Date getUSUFECHACREACION() {
        return USUFECHACREACION;
    }

    public void setUSUFECHACREACION(Date USUFECHACREACION) {
        this.USUFECHACREACION = USUFECHACREACION;
    }

    public short getUSUESTADO() {
        return USUESTADO;
    }

    public void setUSUESTADO(short USUESTADO) {
        this.USUESTADO = USUESTADO;
    }
    
    
}
