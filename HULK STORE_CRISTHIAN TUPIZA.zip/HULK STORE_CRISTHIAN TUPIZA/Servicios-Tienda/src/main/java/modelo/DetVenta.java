/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;

/**
 *
 * @author USER
 */
public class DetVenta {
    private long idDetVenta;
    private long codVenta;
    private int idProducto;
    private String nomProducto;
    private int cantidad;
    private double preUnitario;
    private double preTotal;
    private String usuCreacion;
    private Date fechaCreacion;
    private String tipoDocumento;

    public DetVenta() {
    }

    public DetVenta(long idDetVenta, long codVenta,int idProducto, String nomProducto, int cantidad, double preUnitario, double preTotal, String usuCreacion, Date fechaCreacion, String tipoDocumento) {
        this.idDetVenta = idDetVenta;
        this.codVenta = codVenta;
        this.idProducto = idProducto;
        this.nomProducto = nomProducto;
        this.cantidad = cantidad;
        this.preUnitario = preUnitario;
        this.preTotal = preTotal;
        this.usuCreacion = usuCreacion;
        this.fechaCreacion = fechaCreacion;
        this.tipoDocumento = tipoDocumento;
    }

    public long getIdDetVenta() {
        return idDetVenta;
    }

    public void setIdDetVenta(long idDetVenta) {
        this.idDetVenta = idDetVenta;
    }

    public long getCodVenta() {
        return codVenta;
    }

    public void setCodVenta(long codVenta) {
        this.codVenta = codVenta;
    }


    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNomProducto() {
        return nomProducto;
    }

    public void setNomProducto(String nomProducto) {
        this.nomProducto = nomProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPreUnitario() {
        return preUnitario;
    }

    public void setPreUnitario(double preUnitario) {
        this.preUnitario = preUnitario;
    }

    public double getPreTotal() {
        return preTotal;
    }

    public void setPreTotal(double preTotal) {
        this.preTotal = preTotal;
    }

    public String getUsuCreacion() {
        return usuCreacion;
    }

    public void setUsuCreacion(String usuCreacion) {
        this.usuCreacion = usuCreacion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }
    
}
