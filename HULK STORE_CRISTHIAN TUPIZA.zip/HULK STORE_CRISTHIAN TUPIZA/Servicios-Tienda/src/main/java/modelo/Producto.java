/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;

/**
 *
 * @author USER
 */
public class Producto {
    private int idProd;
    private String nomProd;
    private double descProd;
    private long barProd;
    private String codProd;
    private double preFact;
    private double preExtr;
    private double cosProd;
    private double ganProd;
    private double preVent;
    private double preDesc;
    private double preTotal;

    public Producto() {
    }

    public Producto(int idProd, String nomProd, double descProd, long barProd, String codProd, double preFact, double preExtr, double cosProd, double ganProd, double preVent, double preDesc, double preTotal) {
        this.idProd = idProd;
        this.nomProd = nomProd;
        this.descProd = descProd;
        this.barProd = barProd;
        this.codProd = codProd;
        this.preFact = preFact;
        this.preExtr = preExtr;
        this.cosProd = cosProd;
        this.ganProd = ganProd;
        this.preVent = preVent;
        this.preDesc = preDesc;
        this.preTotal = preTotal;
    }

    public int getIdProd() {
        return idProd;
    }

    public void setIdProd(int idProd) {
        this.idProd = idProd;
    }

    public String getNomProd() {
        return nomProd;
    }

    public void setNomProd(String nomProd) {
        this.nomProd = nomProd;
    }

    public double getDescProd() {
        return descProd;
    }

    public void setDescProd(double descProd) {
        this.descProd = descProd;
    }

    public long getBarProd() {
        return barProd;
    }

    public void setBarProd(long barProd) {
        this.barProd = barProd;
    }

    public String getCodProd() {
        return codProd;
    }

    public void setCodProd(String codProd) {
        this.codProd = codProd;
    }

    public double getPreFact() {
        return preFact;
    }

    public void setPreFact(double preFact) {
        this.preFact = preFact;
    }

    public double getPreExtr() {
        return preExtr;
    }

    public void setPreExtr(double preExtr) {
        this.preExtr = preExtr;
    }

    public double getCosProd() {
        return cosProd;
    }

    public void setCosProd(double cosProd) {
        this.cosProd = cosProd;
    }

    public double getGanProd() {
        return ganProd;
    }

    public void setGanProd(double ganProd) {
        this.ganProd = ganProd;
    }

    public double getPreVent() {
        return preVent;
    }

    public void setPreVent(double preVent) {
        this.preVent = preVent;
    }

    public double getPreDesc() {
        return preDesc;
    }

    public void setPreDesc(double preDesc) {
        this.preDesc = preDesc;
    }

    public double getPreTotal() {
        return preTotal;
    }

    public void setPreTotal(double preTotal) {
        this.preTotal = preTotal;
    }
    
}
