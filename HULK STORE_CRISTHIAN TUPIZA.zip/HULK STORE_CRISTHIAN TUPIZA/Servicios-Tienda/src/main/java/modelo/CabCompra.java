/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;

/**
 *
 * @author USER
 */
public class CabCompra {


    private long idCompra;
    private long codCompra;
    private String nomProveedor;
    private String usuCreacion;
    private Date fechaCreacion;
    private double totalCompra;
    private double ivaCompra;
    private double totalconIva;
    private String usuModificacion;
    private Date fechaModificacion;
    private String tipoDocumento;
    public CabCompra() {
    }

    public CabCompra(long idCompra, long codCompra, String nomProveedor, String usuCreacion, Date fechaCreacion, double totalCompra, double ivaCompra, double totalconIva, String usuModificacion, Date fechaModificacion, String tipoDocumento) {
        this.idCompra = idCompra;
        this.codCompra = codCompra;
        this.nomProveedor = nomProveedor;
        this.usuCreacion = usuCreacion;
        this.fechaCreacion = fechaCreacion;
        this.totalCompra = totalCompra;
        this.ivaCompra = ivaCompra;
        this.totalconIva = totalconIva;
        this.usuModificacion = usuModificacion;
        this.fechaModificacion = fechaModificacion;
        this.tipoDocumento = tipoDocumento;
    }

    public long getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(long idCompra) {
        this.idCompra = idCompra;
    }

    public long getCodCompra() {
        return codCompra;
    }

    public void setCodCompra(long codCompra) {
        this.codCompra = codCompra;
    }

    public String getNomProveedor() {
        return nomProveedor;
    }

    public void setNomProveedor(String nomProveedor) {
        this.nomProveedor = nomProveedor;
    }

    public String getUsuCreacion() {
        return usuCreacion;
    }

    public void setUsuCreacion(String usuCreacion) {
        this.usuCreacion = usuCreacion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public double getTotalCompra() {
        return totalCompra;
    }

    public void setTotalCompra(double totalCompra) {
        this.totalCompra = totalCompra;
    }

    public double getIvaCompra() {
        return ivaCompra;
    }

    public void setIvaCompra(double ivaCompra) {
        this.ivaCompra = ivaCompra;
    }

    public double getTotalconIva() {
        return totalconIva;
    }

    public void setTotalconIva(double totalconIva) {
        this.totalconIva = totalconIva;
    }

    public String getUsuModificacion() {
        return usuModificacion;
    }

    public void setUsuModificacion(String usuModificacion) {
        this.usuModificacion = usuModificacion;
    }

    public Date getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(Date fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }
    
        
}
