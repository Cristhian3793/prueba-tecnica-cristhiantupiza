/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;
import java.util.List;

/**
 *
 * @author CRISTHIAN TUPIZA
 * METODO agregarKardex  PERMITIRA REGRISTRAR LOS MOVIMIENTOS QUE SE HACE CON LOS PRODUCTOS INGRESO DE COMPRAS Y VENTAS
 * METODO listarkardex  PERMITIRA VIUALIZAR TODAS LAS TRANSACCIONES
 * PARAMETROS DEL METODO agregarKardex: 
 * IDPRODUCTO: REPRESENTA EL CODIGO DEL PRODUCTO QUE SE COMPRO O VENDIO  
 * FECHA: PERMITE REGISTRAR LA FECHA DE LA TRANSACCION
 * TIPO DOCUMENTO: PERMITE IDENTIFICAR SI ES UNA COMPRA O UNA VENTA
 * ENTRADA: ES LA CANTIDAD DE PRODUCTOS QUE SE VAN REGISTRANDO
 * SALIDA: ES LA CANTIDAD DE PRODUCTOS QUE SALEN EN LAS VENTAS
 * SALDO: REPRESENTA LA CANTIDAD DE PRODUCTOS QUE QUEDAN
 * 
 */
public interface CRUDKARDEX {
    public List listarkardex();
    public String agregarKardex(int idProducto,Date fecha, String tipoDocumento, double entrada, double salida, double saldo, String tipoMovimiento);   
}
