/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;
import java.util.List;

/**
 *
 * @author CRISTHIAN TUPIZA
 * METODO insertarDetVenta  PERMITIRA REGRISTRAR EL DETALLE DE UNA VENTA 
 * METODO listarDetVenta  PERMITIRA VIUALIZAR LOS DETALLES DE UNA VENTA 
 * PARAMETROS DEL METODO insertarDetVenta: 
 * codventa:Representa un identificador unico que hace referencia a la cabecera de una venta 
 * idProducto:  Representa el codigo de un producto que se vendio
 * nomProducto representa el nombre del producto
 * cantidad: representa la cantidad que se vendio de ese producto
 * preUnitario: representa el precio por unidad del producto
 * preTotal:  representa la cantidad unitaria por la cantidad de productos que se vendieron
 * fechaCreacion: representa la fecha en la que se creo 
 * usuCreacion: representa el usuario que hizo la venta
 * tipoDocumento: representa el tipo de transaccion que es VENT
 */
public interface CRUDDETVENTA {
    public List listarDetVenta();
    public String insertarDetVenta(long codVenta, int idProducto, String nomProducto, int cantidad, double preUnitario, double preTotal, String usuCreacion, Date fechaCreacion, String tipoDocumento);   
    
}
