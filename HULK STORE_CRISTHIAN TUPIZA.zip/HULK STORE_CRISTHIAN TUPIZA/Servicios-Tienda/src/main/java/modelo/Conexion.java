/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author CRISTHIAN TUPIZA
 * CONEXION CON BASE DE DATOS MYSQL
 */
public class Conexion {
    Connection con;
    public Conexion()
    {
    try {
    Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dbfisiodaec","root","admin");
            
    }
    catch(Exception ex){
    }
    }
    public Connection getConnection(){
    return con;
    }
    
}
