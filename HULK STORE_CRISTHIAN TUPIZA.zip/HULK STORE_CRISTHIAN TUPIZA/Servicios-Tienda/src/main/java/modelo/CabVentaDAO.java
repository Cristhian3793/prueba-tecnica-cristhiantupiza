/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author USER
 */
public class CabVentaDAO implements CRUDVENTAS {
    PreparedStatement ps;
    ResultSet  rs;
    Connection con;
    Conexion conex=new Conexion();
    int res;
    String msj;
    @Override
    public List listarventas() {
        List<CabVenta> datos =new ArrayList<>();
        String sql="select * from cabventa";
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
        rs=ps.executeQuery();
        while(rs.next()){
        CabVenta cab=new CabVenta();
        cab.setIdVenta(rs.getLong("idVenta"));
        cab.setCodVenta(rs.getLong("codVenta"));
        cab.setNomcliente(rs.getString("nomcliente"));
        cab.setIdentificacion(rs.getString("identificacion"));       
        cab.setTotalventa(rs.getDouble("totalventa"));
        cab.setIvaVenta(rs.getDouble("ivaVenta"));
        cab.setTotalconIva(rs.getDouble("totalconIva"));
        cab.setUsucreacion(rs.getString("usucreacion"));
        cab.setFechaCreacion(rs.getDate("fechaCreacion"));
        cab.setUsuModificacion(rs.getString("usuModificacion"));
        cab.setFechaModificacion(rs.getDate("FechaModificacion"));
        cab.setTipoDocumento(rs.getString("tipoDocumento"));
        datos.add(cab);
        }
        
        }catch(Exception ex){
        }
        return datos;
    }

    @Override
    public String agregarventa(String nomcliente, String identificacion, double totalventa, double ivaVenta, double totalconIva, String usucreacion, Date fechaCreacion, String usuModificacion, Date fechaModificacion, String tipoDocumento) {
        String sql="insert into cabventa(nomcliente,identificacion,totalventa,ivaVenta,totalconIva,usucreacion,fechaCreacion,usuModificacion,fechaModificacion,tipoDocumento)values(?,?,?,?,?,?,?,?,?,?)";
      
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
       
       
        ps.setString(1, nomcliente);
        ps.setString(2, identificacion);     
        ps.setDouble(3, totalventa);
        ps.setDouble(4, ivaVenta);
        ps.setDouble(5, totalconIva);
        ps.setString(6,usucreacion);
        ps.setDate(7, (java.sql.Date) fechaCreacion);
        ps.setString(8, usuModificacion); 
        ps.setDate(9, (java.sql.Date) fechaModificacion);
        ps.setString(10,tipoDocumento );
        res=ps.executeUpdate();
        if(res==1)
        {
            msj="venta agregada";
        }else
            msj="error";
        }
        catch(Exception ex){}
        
        return msj;
    }

    @Override
    public CabCompra listarID(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
