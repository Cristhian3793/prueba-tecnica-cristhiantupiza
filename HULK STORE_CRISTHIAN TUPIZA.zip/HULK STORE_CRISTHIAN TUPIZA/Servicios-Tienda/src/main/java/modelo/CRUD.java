/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;
import java.util.List;

/**
 *
 * @author CRISTHIA TUPIZA
 * METODOS PARA INGRESO Y VISUALIZACION DE LAS CABECERAS DE COMPRAS 
 */
public interface CRUD {
    public List listarcompra();
    public String agregarcompra(String nomProveedor, String usuCreacion, Date fechaCreacion, double totalCompra, double ivaCompra, double totalconIva, String usuModificacion, Date fechaModificacion, String tipoDocumento);   
    public CabCompra listarID(int id);
}
