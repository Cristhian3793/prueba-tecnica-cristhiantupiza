/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author USER
 */
public class KardexDAO implements CRUDKARDEX {
    PreparedStatement ps;
    ResultSet  rs;
    Connection con;
    Conexion conex=new Conexion();
    int res;
    String msj;

    @Override
    public List listarkardex() {
        List<Kardex> datos =new ArrayList<>();
        String sql="select * from kardex";
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
        rs=ps.executeQuery();
        while(rs.next()){
        Kardex kar=new Kardex();
        kar.setIdKardex(rs.getInt("idKardex"));
        kar.setIdproducto(rs.getInt("idproducto"));
        kar.setFecha(rs.getDate("fecha"));
        kar.setTipoDocumento(rs.getString("tipoDocumento"));
        kar.setEntrada(rs.getDouble("entrada"));
        kar.setSalida(rs.getDouble("salida"));
        kar.setSaldo(rs.getDouble("saldo"));
        kar.setTipoMovimiento(rs.getString("tipoMovimiento"));
        datos.add(kar);
        }   
              
        }catch(Exception ex){
        }
        return datos;
    }

    @Override
    public String agregarKardex(int idProducto,Date fecha, String tipoDocumento, double entrada, double salida, double saldo, String tipoMovimiento) {
        String sql="insert into kardex(idProducto,fecha,tipoDocumento,entrada,salida,saldo,tipoMovimiento)values(?,?,?,?,?,?,?)";      
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
        ps.setInt(1, idProducto); 
        ps.setDate(2, (java.sql.Date) fecha);  
        ps.setString(3, tipoDocumento);
        ps.setDouble(4, entrada);
        ps.setDouble(5, salida);
        ps.setDouble(6, saldo);
        ps.setString(7,tipoMovimiento);
        res=ps.executeUpdate();
        if(res==1)
        {
            msj="kardex agregado";
        }else
            msj="error";
        }
        catch(Exception ex){}
        
        return msj;
    }
    
}
