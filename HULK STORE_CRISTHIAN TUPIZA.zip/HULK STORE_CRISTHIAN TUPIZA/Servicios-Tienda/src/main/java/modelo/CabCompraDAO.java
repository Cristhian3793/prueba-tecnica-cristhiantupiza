/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import java.util.List;

public class CabCompraDAO implements CRUD{
    PreparedStatement ps;
    ResultSet  rs;
    Connection con;
    Conexion conex=new Conexion();
    int res;
    String msj;
    @Override
    public List listarcompra() {
        List<CabCompra> datos =new ArrayList<>();
        String sql="select * from cabcompra";
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
        rs=ps.executeQuery();
        while(rs.next()){
        CabCompra cab=new CabCompra();
        cab.setIdCompra(rs.getLong("idCompra"));
        cab.setCodCompra(rs.getLong("codCompra"));
        cab.setNomProveedor(rs.getString("nomProveedor"));
        cab.setUsuCreacion(rs.getString("usuCreacion"));
        cab.setFechaCreacion(rs.getDate("fechaCreacion"));
        cab.setTotalCompra(rs.getDouble("totalCompra"));
        cab.setIvaCompra(rs.getDouble("ivaCompra"));
        cab.setTotalconIva(rs.getDouble("totalconIva"));
        cab.setUsuModificacion(rs.getString("usuModificacion"));
        cab.setFechaModificacion(rs.getDate("FechaModificacion"));
        cab.setTipoDocumento(rs.getString("tipoDocumento"));
        datos.add(cab);
        }
        
        }catch(Exception ex){
        }
        return datos;
    }

    @Override
    public String agregarcompra(String nomProveedor, String usuCreacion, Date fechaCreacion, double totalCompra, double ivaCompra, double totalconIva, String usuModificacion, Date fechaModificacion, String tipoDocumento) {
        String sql="insert into cabcompra(nomProveedor,usuCreacion,fechaCreacion,totalCompra,ivaCompra,totalconIva,usuModificacion,fechaModificacion,tipoDocumento)values(?,?,?,?,?,?,?,?,?)";
      
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
        ps.setString(1, nomProveedor);
        ps.setString(2, usuCreacion);
        ps.setDate(3, (java.sql.Date) fechaCreacion);  
        ps.setDouble(4, totalCompra);
        ps.setDouble(5, ivaCompra);
        ps.setDouble(6, totalconIva);
        ps.setString(7,usuModificacion);
        ps.setDate(8, (java.sql.Date) fechaModificacion);
        ps.setString(9,tipoDocumento );
        res=ps.executeUpdate();
        if(res==1)
        {
            msj="compra agregada";
        }else
            msj="error";
        }
        catch(Exception ex){}
        
        return msj;
    }

    @Override
    public CabCompra listarID(int id) {
        return null;
    }

    
}
