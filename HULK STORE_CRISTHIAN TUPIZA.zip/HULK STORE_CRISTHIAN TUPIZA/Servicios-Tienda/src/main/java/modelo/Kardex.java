/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;

/**
 *
 * @author CRISTHIAN TUPIZA
 * 
 */
public class Kardex {
    private int idKardex;
    private int idproducto;
    private Date fecha;
    private String tipoDocumento;
    private double entrada;
    private double salida;
    private double saldo;
    private String tipoMovimiento;

    public Kardex() {
    }

    public Kardex(int idKardex, int idproducto, Date fecha, String tipoDocumento, double entrada, double salida, double saldo, String tipoMovimiento) {
        this.idKardex = idKardex;
        this.idproducto = idproducto;
        this.fecha = fecha;
        this.tipoDocumento = tipoDocumento;
        this.entrada = entrada;
        this.salida = salida;
        this.saldo = saldo;
        this.tipoMovimiento = tipoMovimiento;
    }

    public int getIdKardex() {
        return idKardex;
    }

    public void setIdKardex(int idKardex) {
        this.idKardex = idKardex;
    }

    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public double getEntrada() {
        return entrada;
    }

    public void setEntrada(double entrada) {
        this.entrada = entrada;
    }

    public double getSalida() {
        return salida;
    }

    public void setSalida(double salida) {
        this.salida = salida;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getTipoMovimiento() {
        return tipoMovimiento;
    }

    public void setTipoMovimiento(String tipoMovimiento) {
        this.tipoMovimiento = tipoMovimiento;
    }
    
    
}
