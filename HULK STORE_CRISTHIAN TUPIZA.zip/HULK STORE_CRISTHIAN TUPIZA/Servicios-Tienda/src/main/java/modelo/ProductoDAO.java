/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author USER
 */
public class ProductoDAO implements CRUDPRODUCTOS{
    PreparedStatement ps;
    ResultSet  rs;
    Connection con;
    Conexion conex=new Conexion();
    int res;
    String msj;

    @Override
    public List listarproductos() {
        List<Producto> datos =new ArrayList<>();
        String sql="select * from producto";
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
        rs=ps.executeQuery();
        while(rs.next()){
        Producto prod=new Producto();
        prod.setIdProd(rs.getInt("idProd"));
        prod.setNomProd(rs.getString("nomProd"));
        prod.setDescProd(rs.getDouble("desProd"));
        prod.setBarProd(rs.getLong("barProd"));
        prod.setCodProd(rs.getString("codProd"));
        prod.setPreFact(rs.getDouble("preFact"));
        prod.setPreExtr(rs.getDouble("preExtr"));
        prod.setCosProd(rs.getDouble("cosProd"));
        prod.setGanProd(rs.getDouble("ganProd"));
        prod.setPreVent(rs.getDouble("preVent"));
        prod.setPreDesc(rs.getDouble("preDesc"));
        prod.setPreTotal(rs.getDouble("preTotal"));
        datos.add(prod);
        }   
              
        }catch(Exception ex){
        }
        return datos;
    }

   

}
