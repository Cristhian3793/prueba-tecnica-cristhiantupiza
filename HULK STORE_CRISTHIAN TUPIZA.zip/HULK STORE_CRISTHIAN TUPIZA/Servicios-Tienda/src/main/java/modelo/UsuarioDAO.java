/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author USER
 */
public class UsuarioDAO implements CRUDUSUARIO{
    PreparedStatement ps;
    ResultSet  rs;
    Connection con;
    Conexion conex=new Conexion();
    int res;
    String msj;

    @Override
    public List listarUsuarios() {
        List<Usuario> datos =new ArrayList<>();
        String sql="select * from usuario";
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
        rs=ps.executeQuery();
        while(rs.next()){
        Usuario usu=new Usuario();
        usu.setUSUID(rs.getInt("USUID"));
        usu.setUSUALIAS(rs.getString("USUALIAS"));
        usu.setUSUCLAVE(rs.getString("USUCLAVE"));
        usu.setUSUNOMBRE(rs.getString("USUNOMBRE"));
        usu.setUSUAPELLIDO(rs.getString("USUAPELLIDO"));
        usu.setUSUTIPO(rs.getInt("USUTIPO"));
        usu.setUSUFECHACREACION(rs.getDate("USUFECHACREACION"));
        usu.setUSUESTADO(rs.getShort("USUESTADO"));
        datos.add(usu);
        }   
              
        }catch(Exception ex){
        }
        return datos;
    }

    @Override
    public String agregarUsuario(String USUALIAS, String USUCLAVE, String USUNOMBRE, String USUAPELLIDO, int USUTIPO, Date USUFECHACREACION, short USUESTADO) {
        String sql="insert into usuario(USUALIAS,USUCLAVE,USUNOMBRE,USUAPELLIDO,USUTIPO,USUFECHACREACION,USUESTADO)values(?,?,?,?,?,?,?)";      
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
        ps.setString(1, USUALIAS); 
        ps.setString(2,  USUCLAVE);  
        ps.setString(3, USUNOMBRE);
        ps.setString(4, USUAPELLIDO);
        ps.setInt(5, USUTIPO);
        ps.setDate(6, (java.sql.Date) USUFECHACREACION);
        ps.setShort(7,USUESTADO);
        res=ps.executeUpdate();
        if(res==1)
        {
            msj="usuario agregado";
        }else
            msj="error";
        }
        catch(Exception ex){}
        
        return msj;
    }
    
}
