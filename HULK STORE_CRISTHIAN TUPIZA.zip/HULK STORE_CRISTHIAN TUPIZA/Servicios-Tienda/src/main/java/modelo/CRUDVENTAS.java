/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;
import java.util.List;

/**
 *
 * @author USER
 * PERMITE VISUALIZAR E INSERTAR LAS CABECERAS DE UNA VENTA
 */
public interface CRUDVENTAS {
    public List listarventas();
    public String agregarventa(String nomcliente, String identificacion,double totalventa,double ivaVenta, double totalconIva, String usucreacion, Date fechaCreacion,String usuModificacion,Date fechaModificacion ,String tipoDocumento);   
    public CabCompra listarID(int id);
}
