/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;

/**
 *
 * @author USER
 */
public class DetCompra {
    private int idDetCompra;
    private long codCompra;
    private int idProducto;
    private String nomProducto;
    private int cantidad;
    private double preUnitario;
    private double preTotal;
    private String usuCreacion;
    private Date fechaCreacion;
    private String tipoDocumento;

    public DetCompra() {
    }

    public DetCompra(int idDetCompra, long codCompra, int idProducto, String nomProducto, int cantidad, double preUnitario, double preTotal, String usuCreacion, Date fechaCreacion, String tipoDocumento) {
        this.idDetCompra = idDetCompra;
        this.codCompra = codCompra;
        this.idProducto = idProducto;
        this.nomProducto = nomProducto;
        this.cantidad = cantidad;
        this.preUnitario = preUnitario;
        this.preTotal = preTotal;
        this.usuCreacion = usuCreacion;
        this.fechaCreacion = fechaCreacion;
        this.tipoDocumento = tipoDocumento;
    }

    public int getIdDetCompra() {
        return idDetCompra;
    }

    public void setIdDetCompra(int idDetCompra) {
        this.idDetCompra = idDetCompra;
    }

    public long getCodCompra() {
        return codCompra;
    }

    public void setCodCompra(long codCompra) {
        this.codCompra = codCompra;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNomProducto() {
        return nomProducto;
    }

    public void setNomProducto(String nomProducto) {
        this.nomProducto = nomProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPreUnitario() {
        return preUnitario;
    }

    public void setPreUnitario(double preUnitario) {
        this.preUnitario = preUnitario;
    }

    public double getPreTotal() {
        return preTotal;
    }

    public void setPreTotal(double preTotal) {
        this.preTotal = preTotal;
    }

    public String getUsuCreacion() {
        return usuCreacion;
    }

    public void setUsuCreacion(String usuCreacion) {
        this.usuCreacion = usuCreacion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }
    
    
    
}
