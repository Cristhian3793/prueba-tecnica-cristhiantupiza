/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author USER
 */
public class DetVentaDAO implements CRUDDETVENTA{
    PreparedStatement ps;
    ResultSet  rs;
    Connection con;
    Conexion conex=new Conexion();
    int res;
    String msj;
    @Override
    public List listarDetVenta() {
        List<DetVenta> datos =new ArrayList<>();
        String sql="select * from detventa";
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
        rs=ps.executeQuery();
        while(rs.next()){
        DetVenta cab=new DetVenta();
        cab.setIdDetVenta(rs.getInt("idDetVenta"));
        cab.setCodVenta(rs.getLong("codVenta"));
        cab.setIdProducto(rs.getInt("idProducto"));       
        cab.setNomProducto(rs.getString("nomProducto"));
        cab.setCantidad(rs.getInt("cantidad"));
        cab.setPreUnitario(rs.getDouble("preUnitario"));
        cab.setPreTotal(rs.getDouble("preTotal"));
        cab.setUsuCreacion(rs.getString("usuCreacion"));
        cab.setFechaCreacion(rs.getDate("fechaCreacion"));
        cab.setTipoDocumento(rs.getString("tipoDocumento"));
        datos.add(cab);
        }
        
        }catch(Exception ex){
        }
        return datos;
    }

    @Override
    public String insertarDetVenta(long codVenta, int idProducto, String nomProducto, int cantidad, double preUnitario, double preTotal, String usuCreacion, Date fechaCreacion, String tipoDocumento) {
          String sql="insert into detventa (codVenta,idProducto,nomProducto,cantidad,preUnitario,preTotal,usuCreacion,fechaCreacion,tipoDocumento)values(?,?,?,?,?,?,?,?,?)";
      
        try{
        con=conex.getConnection();
        ps=con.prepareStatement(sql);
      
        ps.setLong(1, codVenta);
        ps.setInt(2, idProducto);     
        ps.setString(3, nomProducto);
        ps.setInt(4, cantidad);
        ps.setDouble(5, preUnitario);
        ps.setDouble(6,preTotal);
        ps.setString(7, usuCreacion);
        ps.setDate(8,(java.sql.Date) fechaCreacion); 
        ps.setString(9,  tipoDocumento);
        res=ps.executeUpdate();
        if(res==1)
        {
            msj="venta agregada";
        }else
            msj="error";
        }
        catch(Exception ex){}
        
        return msj;
    }
    
}
