/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;

/**
 *
 * @author USER
 */
public class CabVenta {
    private long idVenta;
    private long codVenta;
    private String nomcliente;
    private String identificacion;
    private double totalventa;
    private double ivaVenta;
    private double totalconIva;
    private String usucreacion;
    private Date fechaCreacion;
    private String usuModificacion;
    private Date fechaModificacion;
    private String tipoDocumento;

    public CabVenta() {
    }

    public CabVenta(long idVenta, long codVenta, String nomcliente, String identificacion, double totalventa, double ivaVenta, double totalconIva, String usucreacion, Date fechaCreacion, String usuModificacion, Date fechaModificacion, String tipoDocumento) {
        this.idVenta = idVenta;
        this.codVenta = codVenta;
        this.nomcliente = nomcliente;
        this.identificacion = identificacion;
        this.totalventa = totalventa;
        this.ivaVenta = ivaVenta;
        this.totalconIva = totalconIva;
        this.usucreacion = usucreacion;
        this.fechaCreacion = fechaCreacion;
        this.usuModificacion = usuModificacion;
        this.fechaModificacion = fechaModificacion;
        this.tipoDocumento = tipoDocumento;
    }

    public long getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(long idVenta) {
        this.idVenta = idVenta;
    }

    public long getCodVenta() {
        return codVenta;
    }

    public void setCodVenta(long codVenta) {
        this.codVenta = codVenta;
    }

    public String getNomcliente() {
        return nomcliente;
    }

    public void setNomcliente(String nomcliente) {
        this.nomcliente = nomcliente;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public double getTotalventa() {
        return totalventa;
    }

    public void setTotalventa(double totalventa) {
        this.totalventa = totalventa;
    }

    public double getIvaVenta() {
        return ivaVenta;
    }

    public void setIvaVenta(double ivaVenta) {
        this.ivaVenta = ivaVenta;
    }

    public double getTotalconIva() {
        return totalconIva;
    }

    public void setTotalconIva(double totalconIva) {
        this.totalconIva = totalconIva;
    }

    public String getUsucreacion() {
        return usucreacion;
    }

    public void setUsucreacion(String usucreacion) {
        this.usucreacion = usucreacion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getUsuModificacion() {
        return usuModificacion;
    }

    public void setUsuModificacion(String usuModificacion) {
        this.usuModificacion = usuModificacion;
    }

    public Date getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(Date fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }
    
}
